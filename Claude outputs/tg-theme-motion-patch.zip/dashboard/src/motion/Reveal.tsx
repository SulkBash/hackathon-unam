import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react'

/**
 * Revela a sus hijos al entrar en pantalla (una sola vez).
 * Marca el contenedor con data-visto; los hijos con data-revelar="rise|pop|draw|fade"
 * se animan con el escalonado de --i (ver index.css, bloque "Motion").
 */
export function useInView<T extends Element>(threshold = 0.18) {
  const ref = useRef<T | null>(null)
  const [visto, setVisto] = useState(false)
  useEffect(() => {
    const el = ref.current
    if (!el || visto) return
    if (typeof IntersectionObserver === 'undefined') {
      setVisto(true)
      return
    }
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setVisto(true)
          io.disconnect()
        }
      },
      { threshold, rootMargin: '0px 0px -8% 0px' },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [threshold, visto])
  return { ref, visto }
}

type RevealProps = { children: ReactNode; className?: string; style?: CSSProperties; id?: string }

export function Reveal({ children, className, style, id }: RevealProps) {
  const { ref, visto } = useInView<HTMLDivElement>()
  return (
    <div ref={ref} id={id} className={className} style={style} data-revelar-grupo="" data-visto={visto ? '' : undefined}>
      {children}
    </div>
  )
}

/** Índice de escalonado para un hijo: style={stagger(2)} → animation-delay = 80 ms + 2 × 70 ms */
export function stagger(i: number): CSSProperties {
  return { ['--i' as string]: i } as CSSProperties
}
