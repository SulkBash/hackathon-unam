/** Cinta tipo transmisión: datos clave en marquesina continua. Se pausa al pasar el mouse y se detiene con reduced motion. */
type Props = { items: string[]; label?: string }

export default function Ticker({ items, label = 'En cifras' }: Props) {
  if (!items.length) return null
  const run = (copy: number) => (
    <div className="flex shrink-0 items-center" data-copia={copy} aria-hidden={copy > 0 ? true : undefined}>
      {items.map((it, i) => (
        <span key={i} className="flex items-center whitespace-nowrap px-6 text-sm text-slate-200">
          <span className="mr-6 inline-block h-1.5 w-1.5 rotate-45 bg-senal" />
          {it}
        </span>
      ))}
    </div>
  )
  return (
    <div className="tg-ticker flex items-stretch border-b border-slate-800 bg-slate-900">
      <div className="tg-ticker-label">{label}</div>
      <div className="tg-ticker-marco relative flex-1 overflow-hidden">
        <div className="tg-ticker-cinta">
          {run(0)}
          {run(1)}
        </div>
      </div>
    </div>
  )
}
