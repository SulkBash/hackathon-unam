import { useEffect, useRef, useState } from 'react'
import { useInView } from './Reveal'

type Props = { value: number; decimals?: number; prefix?: string; suffix?: string; duration?: number; className?: string }

const easeOutQuint = (t: number) => 1 - Math.pow(1 - t, 5)

/** Número que cuenta hasta su valor cuando entra en pantalla. Cifras tabulares para que no "baile". */
export default function CountUp({ value, decimals = 0, prefix = '', suffix = '', duration = 900, className }: Props) {
  const { ref, visto } = useInView<HTMLSpanElement>(0.4)
  const [shown, setShown] = useState(0)
  const raf = useRef(0)
  useEffect(() => {
    if (!visto) return
    const reduce = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    if (reduce) {
      setShown(value)
      return
    }
    const t0 = performance.now()
    const tick = (now: number) => {
      const p = Math.min(1, (now - t0) / duration)
      setShown(value * easeOutQuint(p))
      if (p < 1) raf.current = requestAnimationFrame(tick)
    }
    raf.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf.current)
  }, [visto, value, duration])
  const txt = shown.toLocaleString('es-MX', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })
  return (
    <span ref={ref} className={className} style={{ fontVariantNumeric: 'tabular-nums' }} aria-label={`${prefix}${value.toFixed(decimals)}${suffix}`}>
      {prefix}
      {txt}
      {suffix}
    </span>
  )
}
