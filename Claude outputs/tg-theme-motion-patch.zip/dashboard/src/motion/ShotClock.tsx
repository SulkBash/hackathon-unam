import { useEffect, useRef, useState } from 'react'

/**
 * El reloj de la jugada: la firma visual de "La Guerra de los 3.5 Segundos".
 * - Sin `t`: barre de 0 a `cliff` al montarse (hero) y se queda ahí, con un destello al cruzar.
 * - Con `t` (segundos desde el snap): modo en vivo para la Sala de Video.
 * Zonas: verde < 2.5 s, ámbar 2.5–3.5 s, rojo > 3.5 s (el "precipicio").
 */
type Props = { t?: number; max?: number; cliff?: number; size?: 'sm' | 'lg'; label?: string; endAt?: number; endLabel?: string }

const SAFE = 2.5

function zone(t: number, cliff: number) {
  if (t >= cliff) return { color: '#f43f5e', name: 'Precipicio' }
  if (t >= SAFE) return { color: '#f59e0b', name: 'Zona de riesgo' }
  return { color: '#10b981', name: 'Pocket limpio' }
}

export default function ShotClock({ t, max = 6, cliff = 3.5, size = 'lg', label = 'Tiempo desde el snap', endAt, endLabel }: Props) {
  const [sweep, setSweep] = useState(t ?? 0)
  const raf = useRef(0)
  useEffect(() => {
    if (t !== undefined) return
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    if (reduce) {
      setSweep(cliff)
      return
    }
    const t0 = performance.now() + 500
    const dur = 2400
    const tick = (now: number) => {
      const p = Math.max(0, Math.min(1, (now - t0) / dur))
      setSweep(cliff * (1 - Math.pow(1 - p, 3)))
      if (p < 1) raf.current = requestAnimationFrame(tick)
    }
    raf.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf.current)
  }, [t, cliff])
  const now = Math.max(0, Math.min(max, t ?? sweep))
  const z = zone(now, cliff)
  const pct = (v: number) => `${(v / max) * 100}%`
  const crossed = now >= cliff - 0.001
  const big = size === 'lg'
  const ticks = Array.from({ length: Math.round(max * 10) + 1 }, (_, i) => i / 10)
  return (
    <div className="tg-clock" data-crossed={crossed ? '' : undefined} style={{ ['--zone' as string]: z.color }}>
      <div className="flex items-end justify-between gap-4">
        <div>
          <div className="tg-kicker">{label}</div>
          <div className={`tg-stat ${big ? 'text-7xl' : 'text-4xl'}`} style={{ color: z.color }}>
            {now.toFixed(1)}
            <span className={`${big ? 'text-3xl' : 'text-xl'} text-slate-400`}> s</span>
          </div>
        </div>
        <div className="tg-clock-zone" aria-live="polite">
          <span className="tg-clock-dot" />
          {z.name}
        </div>
      </div>
      <div className={`relative mt-3 ${big ? 'h-12' : 'h-9'}`}>
        <div className="absolute inset-x-0 top-1/2 h-2 -translate-y-1/2 overflow-hidden bg-slate-800">
          <div className="absolute inset-y-0 left-0 bg-emerald-500/25" style={{ width: pct(SAFE) }} />
          <div className="absolute inset-y-0 bg-amber-500/25" style={{ left: pct(SAFE), width: pct(cliff - SAFE) }} />
          <div className="absolute inset-y-0 right-0 bg-rose-500/25" style={{ left: pct(cliff) }} />
          <div className="absolute inset-y-0 left-0 bg-emerald-500" style={{ width: pct(Math.min(now, SAFE)) }} />
          <div className="absolute inset-y-0 bg-amber-500" style={{ left: pct(SAFE), width: pct(Math.max(0, Math.min(now, cliff) - SAFE)) }} />
          <div className="absolute inset-y-0 bg-rose-500" style={{ left: pct(cliff), width: pct(Math.max(0, now - cliff)) }} />
        </div>
        {ticks.map((v) => (
          <span
            key={v}
            className="absolute top-0 w-px bg-slate-600"
            style={{ left: pct(v), height: Number.isInteger(v) ? '100%' : '28%', opacity: Number.isInteger(v) ? 0.9 : 0.5 }}
          />
        ))}
        <span className="tg-clock-cliff" style={{ left: pct(cliff) }}>
          <b>{cliff} s</b>
        </span>
        {endAt !== undefined && (
          <span className="absolute -bottom-5 -translate-x-1/2 font-mono text-[11px] text-slate-300" style={{ left: pct(Math.min(endAt, max)) }}>
            ▲ {endLabel ?? 'Lanzamiento'}
          </span>
        )}
        <span className="tg-clock-needle" style={{ left: pct(now) }} />
      </div>
      <div className="mt-1 flex justify-between font-mono text-[11px] text-slate-500">
        {Array.from({ length: max + 1 }, (_, i) => (
          <span key={i}>{i} s</span>
        ))}
      </div>
    </div>
  )
}
