/** @type {import('tailwindcss').Config} */
// Tema "Transmisión" (dirección A). Re-viste toda la app sin tocar componentes:
// - `slate` pasa a los neutros azul-noche de transmisión (mismas clases, nuevos valores).
// - Radios rectos: rounded-xl/2xl pasan a 4–6 px.
// - `emerald`, `amber` y `rose` NO se tocan: son el semáforo del reloj del pocket.
// - Colores nuevos: `senal` (acento de marca), `offense`, `defense`, `field`.
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        slate: {
          50: '#f2f4f7',
          100: '#e4e8ef',
          200: '#c9d0dc',
          300: '#a9b4c6',
          400: '#8592a8',
          500: '#7a879d',
          600: '#5a6b85',
          700: '#2a3547',
          800: '#1f2a3b',
          900: '#0c121c',
          950: '#06090f',
        },
        senal: { DEFAULT: '#ffc800', ink: '#0a0a0a', strong: '#ffd84d' },
        offense: '#3987e5',
        defense: '#d95926',
        field: '#0a1813',
      },
      fontFamily: {
        sans: ['Barlow', 'system-ui', '"Segoe UI"', 'sans-serif'],
        display: ['"Barlow Condensed"', '"Arial Narrow"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'Consolas', 'monospace'],
      },
      borderRadius: {
        sm: '2px',
        DEFAULT: '2px',
        md: '3px',
        lg: '4px',
        xl: '4px',
        '2xl': '6px',
        '3xl': '8px',
      },
    },
  },
  plugins: [],
}
